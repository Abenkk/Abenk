# BomTelpSmsTokped
## Call/Sms Boomber Tokocash (Tokopedia) OTP

## Cara Pakai
Masukan Nomer hp tujuan di file <b>run.php</b>
<pre>//Eksekusi Call/Sms Boomber (Limit 3x/Jam)
$init->type = 2; //Type 2 untuk telpon, Type 1 untuk sms
$init->no = ""; //Nomer Hp tujuan</pre>

## Note
Saya tidak bertanggung jawab atas resiko (apapun itu).
